----------ATLANTE EOLICO DELL'ITALIA----------


Grid_Nazionale.zip


Il file contiene la copertura in formato ESRI Shapefile che rappresenta la griglia con passo 1.4x1.4 km relativa ai parametri dell'Atlante Eolico dell'Italia.

Nella tabella attributi associata allo Shapefile sono presenti 20 campi numerici contenenti i valori di:
- temperatura media annua espressa in �C, relativa al livello di quota sul livello del terreno/mare di 2 metri;
- velocita' media annua onshore e offshore espressa in m/s, relativa ai livelli di quota sul livello del terreno/mare rispettivamente di 10, 50, 75, 100, 125 e 150 metri;
- densit� di energia eolica onshore e offshore espressa in W/m2, relativa ai livelli di quota sul livello del terreno/mare rispettivamente di 50, 75, 100, 125 e 150 metri;
- producibilita'specifica espressa in MWh/MW, relativa ai livelli di quota sul livello del terreno/mare rispettivamente di 50, 75 e 100 metri onshore e 100, 125 e 150 metri offshore;
- parametro di forma della distribuzione di Weibull, relativo ai livelli di quota sul livello del terreno/mare rispettivamente di 50, 75 e 100 metri onshore e 100 metri offshore.


Le celle sono rappresentate nel sistema di proiezione UTM Fuso 32N sferoide WGS84, come definito nel file associato "Grid_Nazionale.prj".

La griglia contiene un campo denominato "onshore", che riporta il valore 1 se il punto griglia ricade all'interno del dominio onshore o il valore 0 se il punto griglia ricade all'interno del dominio offshore.
I valori di velocit� del vento e producibilit� sono riportati di conseguenza all'interno della griglia.

Vengono forniti due file, "vento_grid_shape.lyr" e "prod_grid_shape.lyr", utili per la rappresentazione tematica dei dati congruente a quella visualizzabile nell'Atlante Eolico interattivo.
