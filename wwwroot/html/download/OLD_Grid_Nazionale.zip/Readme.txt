----------ATLANTE EOLICO DELL'ITALIA----------


Grid_Nazionale.zip


Il file contiene la copertura in formato ESRI Shapefile che rappresenta la griglia con passo 1x1 km relativa ai parametri dell'Atlante Eolico dell'Italia.

Nella tabella attributi associata allo Shapefile sono presenti 8 campi numerici contenenti i valori di velocit� media annua espressi in m/s e di producibilit� specifica espressi in MWh/MW, relativi ai livelli di quota sul livello del terreno/mare rispettivamente di 25, 50, 75 e 100 metri.

Le celle sono rappresentate nel sistema di proiezione UTM Fuso 32N sferoide WGS84, come definito nel file associato "Grid_Nazionale.prj".

Vengono forniti due file, "vento_grid_shape.lyr" e "prod_grid_shape.lyr", utili per la rappresentazione tematica dei dati congruente a quella visualizzabile nell'Atlante Eolico interattivo.
